from django.db import models
#importa o módulo models do pacote django.db

# Create your models here.
class Rotina(models.Model):
  #define uma classe Rotina que herda de models.Model.
  afazeres = models.CharField(max_length = 50)
  #cria um campo de modelo CharField que armazena um máximo de 50 caracteres
  horario = models.TextField()
  #cria um campo de modelo TextField que armazena texto com tamanho ilimitado
  prazo = models.DateField()
  #cria um campo de modelo DateField que armazena datas
  done = models.BooleanField()
  #cria um campo de modelo BooleanField que armazena um valor booleano, que pode ser True ou False

class Tarefa(models.Model):
  #define uma classe Tarefa que herda de models.Model
  necessidades = models.CharField(max_length = 50)
 # cria um campo de modelo CharField que armazena um máximo de 50 caracteres
  horario = models.TextField()
#  cria um campo de modelo TextField que armazena texto com tamanho ilimitado
  prazo = models.DateField()
 # cria um campo de modelo DateField que armazena datas
  done = models.BooleanField()
#cria um campo de modelo BooleanField que armazena um valor booleano, que pode ser True ou False

class User(models.Model):
  #é utilizada a classe models.Model como base para a definição do modelo User
  nome_usuario = models.CharField(max_length = 20)
  #é definido o campo email usando o tipo de campo CharField com  um comprimento máximo de 50 caracteres
  email = models.CharField(max_length = 50)
  #é definido o campo email usando o tipo de campo CharField com um comprimento máximo de 50 caracteres
  senha = models.CharField(max_length = 10)
  #é definido o campo senha usando o tipo de campo CharField com um comprimento máximo de 10 caracteres.
#Esses campos definem as propriedades do modelo User. Com base nessa definição, o Django criará uma tabela no banco de dados para armazenar os dados dos usuários, com os campos correspondentes ao nome_usuario, email e senha definidos no modelo