from django.contrib import admin
#importação do módulo admin do pacote django.contrib
from .models import Rotina
#o modelo Rotina é importado do arquivo models.py do mesmo aplicativo
from .models import Tarefa
#o modelo Rotina é importado do arquivo models.py do mesmo aplicativo

admin.site.register(Rotina)
#registra o modelo Rotina para que ele possa ser gerenciado no painel de administração do Django
admin.site.register(Tarefa)
#registra o modelo Tarefa para gerenciamento no painel de administração do Django
#Isso permite que os usuários com permissão possam criar, atualizar e excluir objetos desses modelos no painel de administração do Django