from django.shortcuts import render, redirect
#importa as funções de renderização e redirecionamento do Django
from .models import Rotina
#importa o modelo Rotina definido no models.py do projeto
from .models import Tarefa
#importa o modelo Tarefa definido no models.py do projeto
from django.contrib.auth.models import User
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout

def home(request):
  #define a função home que é chamada quando o usuário acessa a página inicial do site
    rotinas = Rotina.objects.all()
  #busca todas as rotinas do banco de dados
    tarefas = Tarefa.objects.all()
  #busca todas as tarefas do banco de dados
    context = {"rotinas": rotinas,"tarefas": tarefas}
  #define um contexto que será passado para a página home.html com todas as rotinas e tarefas.
    return render(request, "home.html", context=context)
  #renderiza a página home.html 


def list_rotinas(request):
  #define a função list_rotinas que é chamada quando o usuário acessa a página de listagem de rotinas
    rotinas = Rotina.objects.all()
  #busca todas as rotinas do banco de dados
    context = {"rotinas": rotinas}
  #define um contexto que será passado para a página list_rotinas.html com todas as rotinas
    return render(request, "list_rotinas.html", context=context)
  #renderiza a página list_rotinas.html 
  
def list_tarefas(request):
  #define a função list_tarefas que é chamada quando o usuário acessa a página de listagem de tarefas
    tarefas = Tarefa.objects.all()
  #busca todas as tarefas do banco de dados
    context = {"tarefas": tarefas}
  #define um contexto que será passado para a página list_tarefas.html com todas as tarefas
    return render(request, "list_tarefas.html", context=context)
  #renderiza a página list_tarefas.html

def create_rotina(request):
  #define a função create_rotina que é chamada quando o usuário cria uma nova rotina
    if request.method == "POST":
      #verifica se a requisição é um POST, ou seja, se o usuário enviou um formulário
        if "done" not in request.POST:
            done = False
          #verifica se a rotina foi concluída ou não.
        else:
            done = True
        Rotina.objects.create(afazeres=request.POST["afazeres"],
                            horario=request.POST["horario"],
                            prazo=request.POST["prazo"],
                            done=done)
      #cria uma nova rotina com as informações do formulário enviado pelo usuário
        return redirect("rotinas-list")
      #redireciona o usuário para a página de listagem de rotinas

    return render(request, "Rotina_form.html")
  #caso a requisição não seja um POST, renderiza a página Rotina_form.html com o formulário de criação de rotina


def update_rotina(request, rotina_id):
  #define a função update_rotina que é chamada quando o usuário atualiza uma rotina existente
    rotina = Rotina.objects.get(id=rotina_id)
    rotina.due_date = rotina.due_date.strftime('%Y-%m-%d')

    if request.method == "POST":
      #Verifica se a solicitação do usuário é uma solicitação POST
        rotina.title = request.POST["title"]
      #Atualiza o título da rotina com o valor enviado pelo usuário no formulário
        rotina.description = request.POST["description"]
      #Atualiza a descrição da rotina com o valor enviado pelo usuário no formulário
        rotina.due_date = request.POST["due-date"]
      #Atualiza a data de vencimento da rotina com o valor enviado pelo usuário no formulário
        if "done" not in request.POST:
            rotina.done = False
          #Se o usuário não marcou a caixa de seleção "done" no formulário, define done como False
        else:
            rotina.done = True
          #Se o usuário marcou a caixa de seleção "done" no formulário, define done como True
        rotina.save()
      #Salva as alterações na rotina no banco de dados
        return redirect("rotinas-list")
      #Redireciona o usuário para a lista de rotinas após atualizar a rotina

    return render(request, "rotina_form.html", context={"rotina": rotina})
#Se a solicitação do usuário não for uma solicitação POST, renderiza o modelo rotina_form.html, passando a rotina como contexto

def delete_rotina(request, rotina_id):
  #Define a função que é chamada quando o usuário exclui uma rotina existente
  #O primeiro argumento é request que contém informações sobre a solicitação do usuário. O segundo argumento é rotina_id que é passado na URL para indicar qual rotina deve ser excluída
    rotina = Rotina.objects.get(id=rotina_id)
  #Obtém a rotina correspondente ao rotina_id passado na URL usando o modelo Rotina
    if request.method == "POST":
      #Verifica se a solicitação do usuário é uma solicitação POST
      if "confirm" in request.POST:
        rotina.delete()
        #Se o usuário confirmar a exclusão, exclui a rotina do banco de dados.

      return redirect("rotinas-list")
      #Redireciona o usuário para a lista de rotinas após excluir a rotina

    return render(request, "delete_form.html", context={"rotina": rotina})

def create_tarefa(request):
    if request.method == "POST":
        if "done" not in request.POST:
            done = False
        else:
            done = True
        Tarefa.objects.create(necessidades=request.POST["necessidades"],
                            horario=request.POST["horario"],
                            prazo=request.POST["prazo"],
                            done=done)
        return redirect("tarefas-list")

    return render(request, "Tarefa_form.html")
  #cria uma nova tarefa. Se a solicitação for do tipo "POST", a função verificará se o formulário contém a chave "done". Se sim, então o valor da variável "done" será True, caso contrário, será False. Em seguida, a função cria uma nova instância do modelo Tarefa com os valores fornecidos no formulário e salva no banco de dados. Por fim, a função redireciona o usuário para a página que lista as tarefas


def update_tarefa(request, tarefa_id):
    tarefa = Tarefa.objects.get(id=tarefa_id)
    tarefa.due_date = tarefa.due_date.strftime('%Y-%m-%d')

    if request.method == "POST":
        tarefa.title = request.POST["title"]
        tarefa.description = request.POST["description"]
        tarefa.due_date = request.POST["due-date"]
        if "done" not in request.POST:
            tarefa.done = False
        else:
            tarefa.done = True
        tarefa.save()
        return redirect("tarefas-list")

    return render(request, "tarefa_form.html", context={"tarefa": tarefa})
#é responsável por atualizar uma tarefa existente. A função obtém uma instância do modelo Tarefa com base no "id" da tarefa passada como argumento. Em seguida, converte a data de vencimento em um formato legível. Se a solicitação HTTP for do tipo "POST", a função atualiza a tarefa com os valores fornecidos no formulário e salva no banco de dados. A função redireciona o usuário para a página que lista as tarefas.

def delete_tarefa(request, tarefa_id):
    tarefa = Tarefa.objects.get(id=tarefa_id)
    if request.method == "POST":
      if "confirm" in request.POST:
        tarefa.delete()

      return redirect("tarefas-list")

    return render(request, "delete_form.html", context={"tarefa": tarefa})
#é responsável por excluir uma tarefa existente. A função obtém uma instância do modelo Tarefa com base no "id" da tarefa passada como argumento. Se a solicitação for do tipo "POST" e o usuário confirmar a exclusão, a função exclui a tarefa do banco de dados e redireciona o usuário para a página que lista as tarefas. Caso contrário, a função renderiza um formulário de confirmação de exclusão.

@require_POST
#é utilizado o decorador para garantir que a função só seja executada quando a solicitação HTTP for do tipo "POST"
def cadastrar_usuario(request):
    nome_usuario = request.POST['campo-nome-usuario']
    email = request.POST['campo-email']
    senha = request.POST['campo-senha']
  #extrai os dados do formulário, como o nome de usuário, email e senha

    novoUsuario = User.objects.create_user(username=nome_usuario, email=email, password=senha)
    novoUsuario.save()
  #função User.objects.create_user() para criar um novo usuário com os dados fornecidos e salva-o no banco de dados
  
return render(request, "login.html")
#a função redireciona o usuário para uma página de login
      
@require_POST
def entrar(request):
    usuario_aux = User.objects.get(email=request.POST['email'])
    usuario = authenticate(username=usuario_aux.username,
                           password=request.POST["senha"])
  #função recupera o usuário com base no email fornecido na solicitação POST e autentica o usuário utilizando a função authenticate(), passando o nome de usuário (username) e a senha
    if usuario is not None:
        login(request, usuario)
        return HttpResponseRedirect('/login/')
      # #Se o usuário for autenticado com sucesso, a função faz o login do usuário utilizando a função login(), e redireciona-o para a página de login

    return HttpResponseRedirect('/')
  #Caso contrário, a função redireciona o usuário para a página inicia

@login_required
#para garantir que só usuários autenticados possam acessar a função
def sair(request):
    logout(request)
    return HttpResponseRedirect('/')
  # A função faz o logout do usuário utilizando a função logout() e redireciona-o para a página inicial