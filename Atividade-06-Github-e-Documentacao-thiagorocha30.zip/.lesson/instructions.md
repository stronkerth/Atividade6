# Atividade 06

**PRINCIPAL (700XP)**
- Seguir o passo a passo indicado em sala para jogar o código da Atividade 05 no github;
- Para quem deixou de fazer algo da parte principal de qualquer semana, essa é a chance de entregar tudo que faltou (obrigatório);
- Criar comentários nos códigos dos arquivos models.py, views.py e admin.py (explicações detalhadas, por favor);
- No arquivo README.md, adicionar o passo a passo referente à configuração do Django (tudo que rodaram na linha de comando desde a primeira atividade);

**EXTRA (300XP)**
- Criar um sistema de cadastro/login para o projeto.